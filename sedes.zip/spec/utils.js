const User = require('../models/user');
const Bench = require('../models/bench');
const supertest = require('supertest');
const app = require('../app');

exports.cleanUpDatabaseUser = async function() {
  await Promise.all([
   
    await User.deleteMany()
    
 ]);

};

exports.cleanUpDatabaseBench = async function() {
  await Promise.all([
   
    await Bench.deleteMany()
    
 ]);

};

exports.loginUser = function(auth) {
    return function(done) {
      supertest(app)
            .post('/users/login')
            .send({
              username: 'John Doe', 
              password:'1234'
            })
            .expect(200)
            .end(onResponse);
  
        function onResponse(err, res) {
            auth.token = res.body.token;
            console.log(auth.token)
            return done();
        }
    };

  }